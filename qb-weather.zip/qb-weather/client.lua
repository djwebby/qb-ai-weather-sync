local currentWeather = Config.DefaultWeather
local baseTime = Config.StartHour * 60 + Config.StartMinute
local timeOffset = 0
local freezeTime = false

-- Receive weather update
RegisterNetEvent('qb-weather:updateWeather', function(weather)
    currentWeather = weather
    SetWeatherTypeOverTime(currentWeather, 15.0)
    Wait(15000)
    SetWeatherTypeNowPersist(currentWeather)
    SetWeatherTypeNow(currentWeather)
    SetOverrideWeather(currentWeather)
end)

-- Receive time update
RegisterNetEvent('qb-weather:updateTime', function(base, offset, freeze)
    baseTime = base
    timeOffset = offset
    freezeTime = freeze
end)

-- Time/weather sync loop
CreateThread(function()
    while true do
        Wait(0)
        -- Time sync
        local hour = math.floor(baseTime / 60)
        local minute = math.floor(baseTime % 60)
        NetworkOverrideClockTime(hour, minute, 0)

        -- Weather sync
        ClearOverrideWeather()
        SetWeatherTypeNowPersist(currentWeather)
        SetWeatherTypeNow(currentWeather)
        SetOverrideWeather(currentWeather)
    end
end)
