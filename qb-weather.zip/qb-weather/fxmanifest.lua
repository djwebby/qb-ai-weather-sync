fx_version 'cerulean'
game 'gta5'

author 'YourName'
description 'QBCore Weather & Time Sync'
version '1.0.0'

shared_script 'config.lua'
server_script 'server.lua'
client_script 'client.lua'
