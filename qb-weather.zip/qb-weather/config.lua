Config = {}

-- In-game time speed
Config.TimeCycleSpeed = 2.0 -- 2.0 = twice as fast as real life

-- Default starting time
Config.StartHour = 12
Config.StartMinute = 0

-- Default weather
Config.DefaultWeather = 'EXTRASUNNY'

-- Weather rotation in minutes
Config.WeatherChangeInterval = 15 -- minutes
Config.AvailableWeatherTypes = {
    "EXTRASUNNY",
    "CLEAR",
    "CLOUDS",
    "OVERCAST",
    "RAIN",
    "THUNDER",
    "SMOG",
    "FOGGY"
}

-- Permissions
Config.AdminPermission = 'weatheradmin' -- ACE or QBCore group
