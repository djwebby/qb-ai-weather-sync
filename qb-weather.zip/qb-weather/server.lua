local QBCore = exports['qb-core']:GetCoreObject()

local currentWeather = Config.DefaultWeather
local baseTime = Config.StartHour * 60 + Config.StartMinute
local timeOffset = 0
local freezeTime = false

-- Change weather automatically
CreateThread(function()
    while true do
        Wait(Config.WeatherChangeInterval * 60000)
        local newWeather = Config.AvailableWeatherTypes[math.random(#Config.AvailableWeatherTypes)]
        currentWeather = newWeather
        TriggerClientEvent('qb-weather:updateWeather', -1, currentWeather)
        print('[QB-Weather] Weather changed to ' .. currentWeather)
    end
end)

-- Time sync loop
CreateThread(function()
    while true do
        Wait(2000)
        if not freezeTime then
            baseTime = baseTime + (Config.TimeCycleSpeed * 0.0666666666666667) -- ~1 in-game minute every tick
            if baseTime >= 1440 then baseTime = 0 end
        end
    end
end)

-- Send updates to new players
AddEventHandler('QBCore:Server:PlayerLoaded', function(playerId)
    TriggerClientEvent('qb-weather:updateWeather', playerId, currentWeather)
    TriggerClientEvent('qb-weather:updateTime', playerId, baseTime, timeOffset, freezeTime)
end)

-- Commands
QBCore.Commands.Add('weather', 'Change the weather (Admin Only)', {{name = 'type', help = 'Weather type'}}, false, function(source, args)
    local src = source
    if IsPlayerAceAllowed(src, Config.AdminPermission) or QBCore.Functions.HasPermission(src, 'admin') then
        if args[1] then
            currentWeather = string.upper(args[1])
            TriggerClientEvent('qb-weather:updateWeather', -1, currentWeather)
        else
            TriggerClientEvent('chat:addMessage', src, { args = { '^1SYSTEM', 'Invalid weather type!' } })
        end
    end
end)

QBCore.Commands.Add('time', 'Set the time (Admin Only)', {{name = 'hour', help = 'Hour'}, {name = 'minute', help = 'Minute'}}, false, function(source, args)
    local src = source
    if IsPlayerAceAllowed(src, Config.AdminPermission) or QBCore.Functions.HasPermission(src, 'admin') then
        local hour = tonumber(args[1])
        local minute = tonumber(args[2])
        if hour and minute then
            baseTime = (hour % 24) * 60 + (minute % 60)
            TriggerClientEvent('qb-weather:updateTime', -1, baseTime, timeOffset, freezeTime)
        else
            TriggerClientEvent('chat:addMessage', src, { args = { '^1SYSTEM', 'Invalid time format!' } })
        end
    end
end)
