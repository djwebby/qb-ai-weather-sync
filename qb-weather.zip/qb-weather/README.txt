qb-weather (QBCore Weather & Time Sync)

Install:
1) Unzip and place the 'qb-weather' folder into your server's resources.
2) Add this to your server.cfg:
   ensure qb-weather
3) (Optional) Add ACE permission if not using QBCore admin perms:
   add_ace group.admin weatheradmin allow

Commands:
- /weather <TYPE>   (e.g. EXTRASUNNY, RAIN, THUNDER, FOGGY)
- /time <H> <M>     (24h format)

Config:
- Edit config.lua to change default weather, time, rotation interval, and permissions.

Notes:
- Requires QBCore (qb-core) to be running.
- Weather rotates automatically every Config.WeatherChangeInterval minutes.
